SVatG presents: Puc McAwesome.
==============================

Should work with all major flash carts.

Party coding, fuck yeah.

Code: halcy
Graphics: roB3rnd
Music (NitroTracker and gratuitous DS mic abuse): halcy, yogi